<?php
	header("Access-Control-Allow-Origin: *");
	$url = "http://sandbox.api.simsimi.com/request.p?key=650ba346-911d-40f2-8357-0698c9b71c42&lc=en&ft=1.0&text=" .urlencode($_GET['text']);
	echo file_get_contents($url);

?>