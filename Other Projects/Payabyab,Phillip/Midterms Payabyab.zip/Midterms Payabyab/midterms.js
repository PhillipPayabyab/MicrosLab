var submitBtn =document.getElementById("submit");
		submitBtn.addEventListener("click", function() {
			var newMsg = document.createElement("div");
			newMsg.style.border = "solid 1px black";
			newMsg.style.padding = "10px";
			newMsg.style.background = "yellow";
			

			var newMsg1 = document.createElement("div");
			newMsg1.innerText = document.getElementById("Input").value;

			
			newMsg.appendChild(newMsg1);
			card.appendChild(newMsg);

		})
	