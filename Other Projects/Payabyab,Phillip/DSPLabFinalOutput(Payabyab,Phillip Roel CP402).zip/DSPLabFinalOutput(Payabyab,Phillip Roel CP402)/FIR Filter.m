%Catahan Ryan Christian Y.
%CP-402
clc;
clear all;
close all;
[x1,Fs]=audioread('speech.wav');
for k=1:146
    if k==1
        d(k)=140;
    else
    if mod(k,2)==1
        d(k)= d(k-1)+130;
    else
        d(k)= d(k-1)+20;
    end
    end
end
w = (2.*d')/Fs;
h=fir1(3640,w,'stop');
y=filter(h,1,x1);
sound(x1,Fs);
pause()
sound(y,Fs);
figure(1),subplot(2,1,1);
[Px,Fx] = periodogram(x1,[],length(x1),Fs);
plot(Fx,10*log10(Px));
subplot(2,1,2);
[Py,Fy]=periodogram(y,[],length(y),Fs);
plot(Fy,10*log10(Py));
figure(2),freqz(h);

