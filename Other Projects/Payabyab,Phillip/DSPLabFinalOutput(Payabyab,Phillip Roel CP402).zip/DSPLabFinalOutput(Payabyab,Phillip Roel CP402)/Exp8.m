clc;clear all;
filename=input('Enter audio file to be evaluated: ','s');

[x,fs]=audioread(filename);%input file .wav
sound(x,fs); % read the wav file stored in x.
deltaf=fs/(length(x));
	a=round(5000/deltaf);
	b=round(11025/deltaf);
absfft = abs(fft(x));
lowsum = sum(absfft(1:a));
upsum = sum(absfft((a+1):b));

r=lowsum/upsum;

%if else function.
if r>12 %Threshold is 12.
    disp('The audio file says NO'); %if feature is above threshold return 'no'
else
    disp('The audio file says YES'); %if feature is below threshold return 'yes'
end

